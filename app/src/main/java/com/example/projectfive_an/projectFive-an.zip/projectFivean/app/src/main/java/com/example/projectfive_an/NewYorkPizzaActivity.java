package com.example.projectfive_an;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

public class NewYorkPizzaActivity extends AppCompatActivity {
    private Button backButton;
    private TextView newYorkTitle;
    private RecyclerView pizzaChoosing;
    private RadioButton smallButton;
    private RadioButton mediumButton;
    private RadioButton largeButton;
    private TextView sizeDescription;
    private ListView realToppings;
    private TextView crustDescription;
    private TextView price;
    private Size size;
    /**
     * Default Constructor
     */
    public NewYorkPizzaActivity(){

    }

    /**
     * This method initialize UI components for New York Style Pizza ordering page.
     */
    private void initializeUI(){
        backButton = findViewById(R.id.backButton);
        newYorkTitle = findViewById(R.id.newYorkTitle);
        pizzaChoosing = findViewById(R.id.pizzaChoosing);
        smallButton = findViewById(R.id.smallButton);
        mediumButton = findViewById(R.id.mediumButton);
        largeButton = findViewById(R.id.largeButton);
        sizeDescription = findViewById(R.id.sizeDescription);
        realToppings = findViewById(R.id.realToppings);
        crustDescription = findViewById(R.id.crustDescription);
        price = findViewById(R.id.price);
    }

    /**
     * This method is to set a listener to the back button. Once it is clicked, it will finish the
     * current activity and go back to the main page.
     */
    private void clickBackButton(){
        backButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });
    }

    /**
     * This method provides services for receiving which size of pizza is chosen.
     */
    private void sizeSelection(){
        smallButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                size = Size.SMALL;
            }
        });
        mediumButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                size = Size.MEDIUM;
            }
        });
        largeButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                size = Size.LARGE;
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_yorok_pizza);
        initializeUI();
        clickBackButton();
        sizeSelection();
    }
}